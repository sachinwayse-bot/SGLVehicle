# SGL Vehicle — Android Studio starter project

This is an Android Studio project shell for the SGL Vehicle interface. It packages the current local web interface inside an Android WebView.

## Build an APK
1. Install Android Studio (stable) and the Android SDK for API 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `SGL_Vehicle_Android_Project` folder.
4. Allow Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important limitations
- This is a starter wrapper, not a production-ready fleet system.
- The current interface stores data locally in the app/browser storage; it does not yet sync across phones or computers.
- No Admin/Manager authentication, cloud database, GPS tracking, or production backup is configured yet.
- Before real company use, add secure authentication, server-side access rules, cloud sync, backups, and testing.
- This project does not include a Gradle wrapper; Android Studio can use a locally installed compatible Gradle version or generate wrapper files.

## App details
- App name: SGL Vehicle
- Application ID: `com.sglvehicle.app`
- Minimum Android version: Android 6.0 (API 23)
